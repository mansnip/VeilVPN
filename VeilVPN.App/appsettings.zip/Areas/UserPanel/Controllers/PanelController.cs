﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Domain.ViewModels.UserPanel;
using Application.Services.Interfaces;
using System.Threading.Tasks;

namespace VeilVPN.App.Areas.UserPanel.Controllers
{
    [Area("UserPanel")]
    [Authorize]
    public class PanelController : Controller
    {
        private readonly ISubscriptionService _subscriptionService;
        private readonly IUserService _userService;
        private readonly IInvoiceService _invoiceService;

        public PanelController(ISubscriptionService subscriptionService, IUserService userService, IInvoiceService invoiceService)
        {
            _subscriptionService = subscriptionService;
            _userService = userService;
            _invoiceService = invoiceService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.SignOutAsync();
            return RedirectToAction("SignIn", "Auth", new { area = "Authentication" });
        }

        public IActionResult ChangePassword()
        {
            return View();
        }

        // Buy a new subscription
        public IActionResult BuySubscription()
        {
            return View();
        }


        #region Show Invoice

        [HttpGet]
        public async Task<IActionResult> ShowInvoice(string id)
        {
            try
            {
                // دریافت فاکتور از دیتابیس با استفاده از شناسه
                var invoice = await _invoiceService.GetByIdAsync(id);

                if (invoice == null)
                {
                    TempData["ErrorMessage"] = "فاکتور مورد نظر یافت نشد.";
                    return RedirectToAction("Invoices");
                }

                // ایجاد مدل برای نمایش
                var invoiceViewModel = new InvoiceViewModel
                {
                    InvoiceNumber = invoice.InvoiceNumber,
                    InvoiceDate = invoice.CreatedDate,
                    Subscription = new SubscriptionDetails
                    {
                        Traffic = invoice.Traffic,
                        Duration = invoice.Duration,
                        BasePrice = invoice.BasePrice,
                        DiscountPercent = invoice.DiscountPercent,
                        DiscountAmount = invoice.DiscountAmount,
                        FinalPrice = invoice.FinalPrice
                    }
                };

                return View(invoiceViewModel);
            }
            catch (Exception ex)
            {
                // لاگ کردن خطا
                TempData["ErrorMessage"] = "خطایی در بازیابی اطلاعات فاکتور رخ داده است.";
                return RedirectToAction("Invoices");
            }
        }


        #endregion

        #region ShowInvoicePreview

        [HttpGet]
        public async Task<IActionResult> ShowInvoicePreview(int traffic, int duration)
        {
            try
            {
                // فقط محاسبه قیمت با جزئیات - بدون ذخیره در دیتابیس
                var priceDetails = await _subscriptionService.CalculateDetailedPrice(traffic, duration);

                // ایجاد مدل برای نمایش پیش‌فاکتور
                var invoiceViewModel = new InvoiceViewModel
                {
                    InvoiceNumber = "پیش‌فاکتور", // اینجا شماره فاکتور واقعی ایجاد نمی‌شود
                    InvoiceDate = DateTime.Now,
                    Subscription = new SubscriptionDetails
                    {
                        Traffic = traffic,
                        Duration = duration,
                        BasePrice = priceDetails.BasePrice,
                        DiscountPercent = priceDetails.DiscountPercent,
                        DiscountAmount = priceDetails.DiscountAmount,
                        FinalPrice = priceDetails.FinalPrice
                    }
                };

                // نمایش پیش‌فاکتور بدون ذخیره در دیتابیس
                ViewBag.IsPreview = true; // این مقدار را برای تشخیص پیش‌فاکتور در ویو اضافه می‌کنیم
                ViewBag.Traffic = traffic; // برای استفاده در فرم خرید
                ViewBag.Duration = duration; // برای استفاده در فرم خرید

                return View("ShowInvoice", invoiceViewModel);
            }
            catch (Exception ex)
            {
                // لاگ کردن خطا
                TempData["ErrorMessage"] = "خطایی در محاسبه قیمت رخ داده است. لطفا دوباره تلاش کنید.";
                return RedirectToAction("Index", "Subscription", new { area = "UserPanel" });
            }
        }

        #endregion

        #region CreateInvoice

        [HttpPost]
        public async Task<IActionResult> CreateInvoice(int traffic, int duration)
        {
            try
            {
                // محاسبه قیمت با جزئیات
                var priceDetails = await _subscriptionService.CalculateDetailedPrice(traffic, duration);

                // ذخیره فاکتور در دیتابیس
                var userId = User.Identity.Name;
                var invoice = await _invoiceService.CreateInvoiceAsync(userId, traffic, duration, priceDetails);

                // هدایت به صفحه نمایش فاکتور با استفاده از شناسه فاکتور
                return RedirectToAction("ShowInvoice", new { id = invoice.Id });
            }
            catch (Exception ex)
            {
                // لاگ کردن خطا
                TempData["ErrorMessage"] = "خطایی در ایجاد فاکتور رخ داده است. لطفا دوباره تلاش کنید.";
                return RedirectToAction("Index", "Subscription", new { area = "UserPanel" });
            }
        }

        #endregion


        #region Invoices

        public async Task<IActionResult> Invoices()
        {
            var userId = User.Identity.Name; // باید یک extension method برای گرفتن ID کاربر از کلیم‌های Identity بنویسید
            var invoices = await _invoiceService.GetUserInvoicesAsync(userId);
            return View(invoices);
        }

        #endregion
    }
}
