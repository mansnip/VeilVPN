﻿// Areas/UserPanel/Controllers/SubscriptionController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Application.Services.Interfaces;
using Domain.ViewModels.UserPanel;
using System.Threading.Tasks;

namespace VeilVPN.App.Areas.UserPanel.Controllers
{
    [Area("UserPanel")]
    [Authorize]
    public class SubscriptionController : Controller
    {
        private readonly ISubscriptionService _subscriptionService;

        public SubscriptionController(ISubscriptionService subscriptionService)
        {
            _subscriptionService = subscriptionService;
        }

        // نمایش صفحه اشتراک‌ها
        public IActionResult Index()
        {
            var model = new SubscriptionModel
            {
                Traffic = 30,  // مقدار پیش‌فرض
                Duration = 30  // مقدار پیش‌فرض
            };

            return View(model);
        }

        // اکشن برای محاسبه قیمت (برای درخواست‌های Ajax)
        [HttpPost]
        public async Task<IActionResult> CalculatePrice([FromBody] CalculatePriceModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new { error = "مقادیر ورودی نامعتبر است" });
            }

            try
            {
                // محاسبه قیمت با استفاده از سرویس
                int price = await _subscriptionService.CalculatePrice(model.Traffic, model.Duration);

                // محاسبه درصد تخفیف
                double discount = _subscriptionService.CalculateDiscount(model.Duration);

                return Json(new
                {
                    price = price,
                    discount = discount * 100, // تبدیل به درصد
                    success = true
                });
            }
            catch (Exception ex)
            {
                // ثبت خطا در لاگ
                // _logger.LogError(ex, "خطا در محاسبه قیمت اشتراک");

                return StatusCode(500, new { error = "خطا در محاسبه قیمت. لطفاً دوباره تلاش کنید" });
            }
        }

        // اکشن برای ثبت سفارش اشتراک
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> OrderSubscription(SubscriptionModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", model);
            }

            try
            {
                // محاسبه قیمت نهایی در سمت سرور برای اطمینان از صحت قیمت
                int finalPrice = await _subscriptionService.CalculatePrice(model.Traffic, model.Duration);

                // ایجاد سفارش در دیتابیس
                // ...

                // هدایت به صفحه پرداخت
                return RedirectToAction("Payment", new { price = finalPrice });
            }
            catch
            {
                ModelState.AddModelError("", "خطا در ثبت سفارش. لطفاً دوباره تلاش کنید.");
                return View("Index", model);
            }
        }

        // برای نمایش صفحه پرداخت
        //public IActionResult Payment(int price)
        //{
        //    // مدل مربوط به پرداخت
        //    var paymentModel = new PaymentViewModel
        //    {
        //        Amount = price,
        //        // سایر اطلاعات موردنیاز
        //    };

        //    return View(paymentModel);
        //}

        // سایر اکشن‌های مربوط به اشتراک
    }
}